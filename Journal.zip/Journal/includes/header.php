
<html>
  <head>
     <title>Journal Upload and Retrieval System</title>
	 <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type" />
     <meta name="viewport" content="width=100% height =100%,initial-scale=0.7,maximum-scale=1.0,user-scalable=no">
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
     <meta name="HandheldFriendly" content="true">
	 
	   <link rel ="stylesheet" type ="text/css" href ="style.css">
	   <link rel ="shortcut-icon" href ="../images/logo.ico" />
  </head>
  
  <body>
  <div style ="height:3px; background-color:white; width:80%;"></div>
  <center>
  <div style ="height:5px; background-color:lightblue; width:80%;"></div>
  </center>
  <div align ="center">
  <img style ="height:80px; height:80px;" align ="center" src ="images/logo.jpg">
  </div>
  </body>
  
  <center>
  <div style ="height:50px; background-color:lightblue; width:95%;" align ="center">

  
  <a href ="index.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Home</a>
  
  <a href ="moderator/dashboard.php" style ="background-color: gray;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Moderator Login</a> 
  
  <a href ="user/dashboard.php" style ="background-color: lightgreen;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">User Login</a></li>
    </ul>
  </div>
    <div style ="height:60px; background-color:white; width:95%;" align ="center">