<?php include "includes/header.php";?>

<center>
<div style ="height:500px; width:350px;">
</div>
</center>

<form action ="" method ="post" align ="left">
<input type ="text" name ="chat" style ="width:1000px;"></input><button type ="submit" value="Post">Post</button>
</form>
<?php include "includes/footer.php";?>