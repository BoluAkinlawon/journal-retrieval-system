<?php include "includes/header.php";?>
<?php include "includes/config.php";?>

<center>
<div style ="height:500px; width:350px;">
<form action ="" method ="post" enctype ="">
	<h3>Search for Journal...</h3>
	<input type ="text" name ="journal"></input required><br>
	<button type = "submit" name ="search">Search</button>
	</form>
</div>
</center>



<?php include "includes/footer.php";?>