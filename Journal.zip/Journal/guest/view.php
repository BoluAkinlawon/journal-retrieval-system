<?php include "includes/header.php";?>
<html>
<head>
<link rel ="stylesheet" type ="text/css" href="includes/style.css">
<style>
table {
border-collapse: collapse;
width: 99.8%;
color: #588c7e;
margin: 1px;
font-family: Arial, "Trebuchet MS", Helvetica;
font-size: 20px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: lightgreen;}
</style>
</head>


<center>
<div style ="height:auto; width:100%; background:;">
<table>
<tr>
<th>id</th>
<th>Username</th>
<th>Title</th>
<th>Category</th>
<th>Post</th>
<th>Date and Time</th>

</tr>
<?php
$connection =mysqli_connect("localhost","root","");
$db =mysqli_select_db($connection, "wellsprings");

$query2 ="SELECT DISTINCT id, title, category, date_time, post, username from post where id is not null";
$query_run2 = $connection -> query($query2);

  if($query_run2 -> num_rows > 0){
      while($row = $query_run2 -> fetch_assoc()){
      echo "<tr><td>".$row["id"]."</td><td>".$row["username"]."</td><td>".$row["title"]."</td><td>".$row["category"]."</td><td>".$row["post"]."</td><td>".$row["date_time"]."</td></tr>";
	
	 
      }
        echo "</table>";
  }
  else {
      echo "No messages yet";
  }

  $connection -> close();
?>

<div style ="width:100%; height:5px; background:white;">
</div>
</div>
</div>
</center>
<div style ="height:2px; width:100%; background:white;">
</div>
</html>
<?php include "includes/footer.php";?>