<?php include "includes/header.php";?>
<?php
$connection =mysqli_connect("localhost","root","");
$db =mysqli_select_db($connection, "journal");

session_start();
if(!isset($_SESSION['username'])){
	echo"You are not logged in to see content";
	header("location:login.php");
}else{
	
}
?>
<?php
$connection =mysqli_connect("localhost","root","");
$db =mysqli_select_db($connection, "journal");
$session = $_SESSION['username'];
echo "Welcome ". $session;
?>

<html>
<head>
<link rel ="stylesheet" href ="style.css">
</head>
<center>
<style>
table{
	width:60%;
	border-collapse: collapse;
	margin: 100px auto;
}
th, td{
	height:50px;
	vertical-align:center;
	border: 1px solid black;
}

</style>


<hr>
<div style ="height:42px; width:100%;">
<form action ="" method ="post" align ="right">
<button type ="submit" name ="logout" value ="logout"  style ="margin:5px;">Log Out</button>
</form>
</div>
<?php
if(isset($_POST['logout'])){
	session_destroy();
	header("location:login.php");
}
 echo "<p style ='margin:5px;' align =right>"."<a href =  style ='background:white;'>Change password</a>"."</br>";
 //echo "<p style ='margin:5px;' align =right>".$_SESSION['phone']."</br>";

?>


<html>
<fieldset style ="width:200px; height:auto;">
View Available Journals
</fieldset>

<div class ="row">

<table>
<thead>
    <th>ID</th>
	<th>Name</th>
	<th>File size(MB)</th>
	<th>Downloads</th>
	<th>Action</th>
</thead>
<tbody>
<?php
$conn = mysqli_connect("localhost", "root", "", "journal");
$sql = "SELECT *from file";

$result = mysqli_query($conn, $sql);
$files = mysqli_fetch_all($result, MYSQLI_ASSOC);

?>

<?php foreach ($files as $file): ?>
<tr>
 <td><?php echo $file['id'];?></td>
 <td><?php echo $file['given_name'];?></td>
 <td> <?php echo $file['size'] / 1000 . "KB";?> </td>
 <td><?php echo  $file['downloads'];?></td>
 <td>
<a href = "dashboard.php?file_id= <?php echo $file['id']?>">Download</a>
 </td>
</tr>
<?php endforeach ; ?>
</tbody>
</table>

<?php 
if(isset($_GET['file_id'])){
	$id = $_GET['file_id'];
	$sql = "SELECT * from file where id = $id";
	
	$result = mysqli_query($conn, $sql);
	
	$file = mysqli_fetch_assoc($result);
	
	$filepath = '../user/uploads/'. $file['name'];
	
	if(file_exists($filepath)){
		header('Content-Type: application/octet-stream');
		header('Content-Decription: File Transfer');
		
		header('Content-Disposition: attachment; filename='.
		basename($filepath));
		
		header('Expires: 0');
		
		header('Cache-Control: must-revalidate');
		header('Pragma:public');
		
		header('Content-Length:' . filesize('uploads/'.$file['name']));
		
		readfile('uploads/'. $file['name']);
		
		$newCount = $file['downloads'] + 1;
		$updatQuery ="UPDATE file SET downloads = $newCount WHERE id = $id";
		
		mysqli_query($conn, $updatQuery);
		exit;
		
	}
}


?>
</div>

</html>
<center>
<div style ="height:auto; width:65%; background:lightblue;" align ="left">

<div style ="background:white; height:5px; width:100%;">
</div>
</div>
</center>
</html>

<?php include "includes/footer.php";?>