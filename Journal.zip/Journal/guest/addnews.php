<?php include "includes/header.php";?>
<html>
<head>
<link rel ="stylesheet" type ="text/css" href="includes/style.css">
<style>
table {
border-collapse: collapse;
width: 99.8%;
color: #588c7e;
margin: 1px;
font-family: Arial, "Trebuchet MS", Helvetica;
font-size: 20px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: lightgreen;}
</style>
</head>
<center>
<?php
$connection =mysqli_connect("localhost","root","");
$db =mysqli_select_db($connection, "wellsprings");

session_start();
if(!isset($_SESSION['username'])){
	echo"You are not logged in to see content";
	header("location:login.php");
}else{
	
}



?>
<hr>
<div style ="height:42px; width:100%;">
<form action ="" method ="post" align ="right">
<button type ="submit" name ="logout" value ="logout"  style ="margin:5px;">Log Out</button>
</form>
</div>
<?php
if(isset($_POST['logout'])){
	session_destroy();
	header("location:login.php");
}
 echo "<p style ='margin:5px;' align =right>"."<a href =''  style ='background:white;'>Change password</a>"."</br>";
  echo "<p style ='margin:5px;' align =right>"."<a href =''  style ='background:white;'>Add news</a>"."</br>";
 //echo "<p style ='margin:5px;' align =right>".$_SESSION['phone']."</br>";

?>

<?php
$connection =mysqli_connect("localhost","root","");
$db =mysqli_select_db($connection, "wellsprings");
if(isset($_POST['submit'])){
	$news = $_POST['news'];
	$title =$_POST['title'];
	$query ="INSERT INTO news(title, news) VALUES ('$title', '$news')";
	$query_run =mysqli_query($connection, $query);
	
		
}
?>
<html>
<fieldset style ="width:200px; height:auto;">
Create News/ Blog post
<form action ="" method ="post">
Title<input name ="title" style="width: 250px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;"></input>
 Category<select name="category">
  <option value ="">--------------</option>
 <option value ="Education">Education</option>
 <option value =""></option>
  </select>
  <br>
  <br>
  <textarea  name = "news" style="width: 250px; height: 200px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;" required></textarea>
  Upload file
  <input type ="submit" name ="submit"></input>
</form>
</fieldset>
</html>
<center>
<div style ="height:auto; width:100%; background:lightblue;" align ="left">
<div style ="height:auto; width:100%; background:;">

</tr>
<?php

?>

<div style ="width:100%; height:5px; background:white;">
</div>
</div>
</div>
</center>
</html>

<?php include "includes/footer.php";?>