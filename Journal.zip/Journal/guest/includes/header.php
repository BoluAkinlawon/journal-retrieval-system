
<html>
  <head>
     <title>Journals</title>
	   <link rel ="stylesheet" type ="text/css" href ="style.css">
	   <link rel ="shortcut-icon" href ="../images/logo.ico" />
  </head>
  
  <body>
  <div style ="height:3px; background-color:white; width:80%;"></div>
  <center>
  <div style ="height:5px; background-color:lightblue; width:80%;"></div>
  </center>
  <div align ="center">
  <img style ="height:80px; height:80px;" align ="center" src ="images/logo.jpg">
  </div>
  </body>
  
  <center>
  <div style ="height:50px; background-color:lightblue; width:95%;" align ="center">
  
  
  <a href ="../index.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Home</a>
  
  <a href ="login.php" style ="background-color: gray;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Login</a> 
  
    </ul>
  </div>
    <div style ="height:60px; background-color:white; width:95%;" align ="center">