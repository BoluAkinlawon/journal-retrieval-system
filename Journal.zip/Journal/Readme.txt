Past Question project
Create to a database and name it journal, then
Import the journal.sql file
Admin Login: 
   username:admin
   password:admin
   TO upload files, click on user login on the home page then register and login
   TO retrieve, click on guest login on the home page and register then login