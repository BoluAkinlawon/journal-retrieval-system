<?php

session_start();
if(!isset($_SESSION['username'])){
	echo"You are not logged in to see content";
	header("location:login.php");
}else{
	
}

?>
<?php

/**
 * Delete a user
 */

require "includes/config2.php";

$success = null;

if (isset($_POST["submit"])) {
  

  try {
    $connection = new PDO($dsn, $username, $password, $options);
  
    $id = $_POST["submit"];

    $sql = "DELETE FROM student WHERE id = :id";

    $statement = $connection->prepare($sql);
    $statement->bindValue(':id', $id);
    $statement->execute();

    $success = "User successfully deleted";
  } catch(PDOException $error) {
    echo $sql . "<br>" . $error->getMessage();
  }
}

try {
  $connection = new PDO($dsn, $username, $password, $options);

  $sql = "SELECT * FROM student";

  $statement = $connection->prepare($sql);
  $statement->execute();

  $result = $statement->fetchAll();
} catch(PDOException $error) {
  echo $sql . "<br>" . $error->getMessage();
}
?>
<?php require "includes/header.php"; ?>
        
<h2>Delete users</h2>

<?php if ($success) echo $success; ?>

<form method="post">
  
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Full Name</th>
        <th>Username</th>
        <th>Email Address</th>
        <th>Matric</th>
        <th>Course</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($result as $row) : ?>
      <tr>
        <td><?php echo ($row["id"]); ?></td>
        <td><?php echo ($row["fullname"]); ?></td>
        <td><?php echo ($row["username"]); ?></td>
        <td><?php echo ($row["email"]); ?></td>
        <td><?php echo ($row["matric"]); ?></td>
        <td><?php echo ($row["course"]); ?></td>
        <td><button type="submit" name="submit" value="<?php echo ($row["id"]); ?>">Delete</button></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</form>

<a href="index.php">Back to home</a>

<?php require "includes/footer.php"; ?>