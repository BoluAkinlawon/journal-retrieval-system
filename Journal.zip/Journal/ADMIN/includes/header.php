
<html>
  <head>
     <title>Online Forum</title>
	 <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type" />
     <meta name="viewport" content="width=100% height =100%,initial-scale=0.7,maximum-scale=1.0,user-scalable=no">
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
     <meta name="HandheldFriendly" content="true">
	 
	   <link rel ="stylesheet" type ="text/css" href ="style.css">
	   <link rel ="shortcut-icon" href ="../images/logo.ico" />
  </head>
  
  <body>
  <div style ="height:3px; background-color:white; width:80%;"></div>
  <center>
  <div style ="height:5px; background-color:lightblue; width:80%;"></div>
  </center>
  <div align ="center">
  <img style ="height:80px; height:80px;" align ="center" src ="images/logo.jpg">
  </div>
  </body>
  
  <center>
  <div style ="height:50px; background-color:lightblue; width:95%;" align ="center">

  
  <a href ="dashboard.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Home</a>
  
  <a href ="" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">News</a> 
  
  <a href ="" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Forum</a>
  
  <a href ="" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;"> Members </a>
  
  <a href ="" style ="background-color: gray;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Guest Login</a> 
  
  <a href ="" style ="background-color: lightgreen;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Student Login</a></li>
    </ul>
  </div>
  <div style = "height:50; width:100%; background:white;">

	<a href="create.php"><strong>Create</strong></a> 
	<a href="read.php"><strong>Read</strong></a> 
	<a href="update.php"><strong>Update</strong></a> 
	<a href="delete.php"><strong>Delete</strong></a>

</div>
    <div style ="height:40px; background-color:white; width:95%;" align ="center">