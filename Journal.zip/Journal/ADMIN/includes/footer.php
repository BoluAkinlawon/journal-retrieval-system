<html>
<head>
     <title>Online Forum</title>
	   <link rel ="stylesheet" type ="text/css" href ="style.css">
	   <link rel ="shortcut-icon" href ="images/logo.ico" />
  </head>
<center>
  <div class ="footer"  style ="height:30px; background-color:lightblue; width:100%;" align ="center">
  @Copyright 
  </div>
  </center>
  
  <div style ="height:3px; background-color:white; width:80%; "></div>
  
</html>