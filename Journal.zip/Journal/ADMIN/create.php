<?php include "includes/header.php"; ?>
<?php

session_start();
if(!isset($_SESSION['username'])){
	echo"You are not logged in to see content";
	header("location:login.php");
}else{
	
}

?>
<?php

if(isset($_POST['submit'])){
	$fullname = $_POST['fullname'];
	$email = $_POST['email'];
	$matric = $_POST['matric'];
	$course = $_POST['course'];
	$username = $_POST['fullname'];
	$password = $_POST['matric'];
	
	$query ="INSERT INTO student(fullname, username, email, matric, course, password) VALUES ('$fullname','$username','$email','$matric','$course','$password')";
	$query_run =mysqli_query($connection, $query);
	if($query_run){
		echo "Student Added Succesfully";
	}
	else{
		echo "Error";
	}
}


?>


  <head>
  <link rel="stylesheet" type ="text/css" href ="style.css" >
  </head>

  <h2 style ="Color:black;">Add a Student</h2>
<div>
  <form method="post">
    
    <label for="fullname">Full Name</label>
    <input type="text" name="fullname" id="fullname">
    <label for="email">Email Address</label>
    <input type="text" name="email" id="email">
    <label for="matric">Matric Number</label>
    <input type="text" name="matric" id="matric">
    <label for="location">Course</label>
    <input type="text" name="course" id="course">
    <input type="submit" name="submit" value="Submit" style ="background:lightgreen;">
  </form>
  </div>

  <i><a href="dashboard.php" style ="background:white;">Back to home</a></i>
  <div style ="height:55px; width:100%; background:white;">
  </div>

<?php include "includes/footer.php"; ?>
