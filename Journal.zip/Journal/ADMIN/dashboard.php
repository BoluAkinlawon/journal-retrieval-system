<?php include "includes/header.php"; ?>
<?php

session_start();
if(!isset($_SESSION['username'])){
	echo"You are not logged in to see content";
	header("location:login.php");
}else{
	
}

?>
<hr>
<div style ="height:42px; width:100%;">
<form action ="" method ="post" align ="right">
<button type ="submit" name ="logout" value ="logout"  style ="margin:5px;">Log Out</button>
</form>
</div>
<?php
if(isset($_POST['logout'])){
	session_destroy();
	header("location:login.php");
}

 //echo "<p style ='margin:5px;' align =right>".$_SESSION['phone']."</br>";

?>
 </center>
  <div>
  <img style ="height:500px; height:500px;" align ="center" src ="images/back.jpg">
  </div>
<?php include "includes/footer.php"; ?>
