<?php

session_start();
if(!isset($_SESSION['username'])){
	echo"You are not logged in to see content";
	header("location:login.php");
}else{
	
}

?>
<?php

/**
 * List all users with a link to edit
 */

require "includes/config2.php";

try {
  $connection = new PDO($dsn, $username, $password, $options);

  $sql = "SELECT * FROM student";

  $statement = $connection->prepare($sql);
  $statement->execute();

  $result = $statement->fetchAll();
} catch(PDOException $error) {
  echo $sql . "<br>" . $error->getMessage();
}
?>

<?php require "includes/header.php"; ?>
        
<h2>Update users</h2>
<head>
<style>
table {
border-collapse: collapse;
width: 99.8%;
color: #588c7e;
margin: 1px;
font-family: Arial, "Trebuchet MS", Helvetica;
font-size: 20px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: lightgreen;}
</style>
</head>
<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Fullname</th>
            <th>Username</th>
            <th>Email Address</th>
            <th>Matric Number</th>
            <th> Course</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($result as $row) : ?>
        <tr>
            <td><?php echo ($row["id"]); ?></td>
            <td><?php echo ($row["fullname"]); ?></td>
            <td><?php echo ($row["username"]); ?></td>
            <td><?php echo ($row["email"]); ?></td>
            <td><?php echo ($row["matric"]); ?></td>
            <td><?php echo ($row["course"]); ?></td>
            <td><button name ="edit">Edit</button></td>
        </tr>
    <?php endforeach; ?>
	<?php
	
	
	?>
    </tbody>
</table>

<a href="index.php">Back to home</a>
<div style ="background:white; height:2px; width: 100%;">
</DIV>
<?php require "includes/footer.php"; ?>