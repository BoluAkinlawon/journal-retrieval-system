
<?php include "includes/header.php"; ?>
<?php

session_start();
if(!isset($_SESSION['username'])){
	echo"You are not logged in to see content";
	header("location:login.php");
}else{
	
}

?>
 <html>
<head>
<link rel ="stylesheet" type ="text/css" href="includes/style.css">
<style>
table {
border-collapse: collapse;
width: 99.8%;
color: #588c7e;
margin: 1px;
font-family: Arial, "Trebuchet MS", Helvetica;
font-size: 20px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: lightgreen;}
</style>
</head>
<div style ="height:auto; width:100%;">
<table>
<tr>
<th>id</th>
<th>Fullname</th>
<th>Username</th>
<th>Matric</th>
<th>Course</th>
</tr> 
<?php  
include "includes/config.php";
if (isset($_POST['submit'])) {
  $item= $_POST['item'];
  
  $query ="SELECT * from student where  fullname ='$item' OR username ='$item' OR email ='$item' OR matric ='$item' OR course ='$item'";
  $query_run = $connection -> query($query);
  
  if($query_run -> num_rows > 0){
      while($row = $query_run -> fetch_assoc()){
      echo "<tr><td>".$row["id"]."</td><td>".$row["fullname"]."</td><td>".$row["username"]."</td><td>".$row["email"]."</td><td>".$row["matric"]."</td><td>".$row["course"]."</td></tr>";
	
	 
      }
        echo "</table>";
		echo "</div>";
  }
  else {
      echo "No results";
  }

  $connection -> close();
} 

?> 

<h2>Search for Students and post</h2>

<form method="post">
  
  <label for=""></label>
  <input type="text" id="item" name="item">
  <input type="submit" name="submit" value="View Results">
</form>

<a href="index.php">Back to home</a>
</html>
<?php require "includes/footer.php"; ?>