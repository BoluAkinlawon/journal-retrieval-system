<?php include "includes/header.php";?>


<?php
include "includes/config.php";

if(isset($_POST['submit'])){
	$fullname = $_POST['fullname'];
	$username = $_POST['username'];
	$matric = $_POST['matric'];
	$email = $_POST['email'];
	$course = $_POST['course'];
	$password = md5($_POST['password']);
	
	
   
 
  $query = "INSERT INTO student(fullname, username, email, course, matric, password) VALUES ('$fullname', '$username', '$email', '$course', '$matric', '$password')";
  $query_run = mysqli_query($connection, $query);
  
  
  
  if($query_run){
	  header("location:login.php");
	  
  
	 //header("location:register.php");
	
	 
 }else if(!$query_run){
	  echo "Error"; 
  }
  
   
	  
}
?>
<center>
<div style ="width:250px;">
<fieldset style ="background:white;">
<form action ="" method ="post">
<div style ="width:250px; height:45px; background:gray;"></div>
<div style ="width:250px; height:5px; background:white;"></div>

<input name ="fullname" type ="text" placeholder ="Fullname" style="width: 250px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;"></></input>
<input name ="username" type ="text" placeholder ="Username" style="width: 250px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;"></></input>
<input name ="email" type ="email" placeholder ="Email" style="width: 250px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;"></></input>
<input name ="matric" type ="text" placeholder ="Matric Number" style="width: 250px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;"></></input>
<input name ="course" type ="text" placeholder ="Course" style="width: 250px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;"></></input>
<input name ="password" type ="password" placeholder ="Password" style="width: 250px; height: 30px; text=border: 1px solid brown; border-radius: 05px; padding: 20px 15px 20px 15px; margin: 10px 0px 15 px 0px;"></></input>

<input type ="submit" name="submit"></input>
</form>
</fieldset>
</div>
</center>


<?php include "includes/footer.php";?>