<?php include "includes/header.php";?>
<html>
<html>
<head>
<link rel ="stylesheet" type ="text/css" href="includes/style.css">
<style>
table {
border-collapse: collapse;
width: 99.8%;
color: #588c7e;
margin: 1px;
font-family: Arial, "Trebuchet MS", Helvetica;
font-size: 20px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: lightgreen;}
</style>
</head>
<center>
<?php
$connection =mysqli_connect("localhost","root","");
$db =mysqli_select_db($connection, "journal");

session_start();
if(!isset($_SESSION['username'])){
	echo"You are not logged in to see content";
	header("location:login.php");
}else{
	
}
?>
<?php

$session= $_SESSION['username'];

?>
<hr>
<div style ="height:42px; width:100%;">
<form action ="" method ="post" align ="right">
<button type ="submit" name ="logout" value ="logout"  style ="margin:5px;">Log Out</button>
</form>
</div>
<?php
if(isset($_POST['logout'])){
	session_destroy();
	header("location:login.php");
}
 echo "<p style ='margin:5px;' align =right>"."<a href =''  style ='background:white;'>Change password</a>"."</br>";
  
 //echo "<p style ='margin:5px;' align =right>".$_SESSION['phone']."</br>";

?>
<?php
$conn = mysqli_connect("localhost","root","","journal");

$sql = "SELECT *from file";

$result = mysqli_query($conn, $sql);
$files = mysqli_fetch_all($result, MYSQLI_ASSOC);
if(isset($_POST['save'])){
	$filename = $_FILES['myfile']['name'];
	$destination = 'uploads/' . $filename;
	$extension = pathinfo($filename, PATHINFO_EXTENSION);
	$file = $_FILES['myfile']['tmp_name'];
	$size = $_FILES['myfile']['size'];
	$given = $_POST['given_name'];
	
	if(!in_array($extension, ['zip','pdf','png'])){
		echo "Your file extension must be .zip. pdf or .png";
		
	}
	elseif($_FILES['myfile']['size'] > 10000000){
		echo "file is too large";
		
	}
	else{
		if(move_uploaded_file($file, $destination)){
			$sql = "INSERT INTO file(given_name, name, size, downloads) 
			VALUES ('$given', '$filename','$size',0)";
			if(mysqli_query($conn, $sql)){
				echo "file uploaded succesfully";
			}
			else{
				echo "failed to upload file";
			}
		}
	}
}
?>
<fieldset style = "border-radius:15px">
<div class ="container">
            <div class ="row">
			<form action ="" method ="post" enctype ="multipart/form-data">
	<h3>Upload Files</h3>
	<input type ="text" name ="given_name" placeholder ="Name of Document"></input required><br>
	<input type ="file" name ="myfile"></input required><br>
	<button type = "submit" name ="save">Upload</button>
	</form>
            </div>
			
       </div>
    
 </body>

<br />
<div style="text-align:center">

</div>
</fieldset>
<br><br>
<?php include "includes/footer.php";?>